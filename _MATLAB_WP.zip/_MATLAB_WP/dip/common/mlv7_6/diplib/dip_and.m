%dip_and   Logical and between two images.
%    out = dip_and(in1, in2)
%
%   in1
%      Image.
%   in2
%      Image.

% (C) Copyright 2011, Cris Luengo.
% Centre for Image Analysis, Uppsala, Sweden.
