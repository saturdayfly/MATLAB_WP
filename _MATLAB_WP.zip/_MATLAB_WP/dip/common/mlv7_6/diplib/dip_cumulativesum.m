%dip_cumulativesum    statistics function.
%    out = dip_cumulativesum(in, mask, ps)
%
%   in
%      Image.
%   mask
%      Mask image. Can be [] for no mask.
%   ps
%      Boolean array.

% (C) Copyright 2005-                   Quantitative Imaging Group
%     All rights reserved               Applied Physics Laboratory
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
