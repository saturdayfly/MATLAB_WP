%dip_drawline   .
%    out = dip_drawline(image, start, end, color)
%
%   image
%      Image.
%   start
%      Integer number.
%   end
%      Integer number.
%   color
%      Real number.

% (C) Copyright 1999-2000               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, February-July 1999.

