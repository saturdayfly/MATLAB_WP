%dip_croptobetterfouriersize   Crops to a size more suitable to the FFT algorithm.
%    out = dip_croptobetterfouriersize(in, process)
%
%   in
%      Image.
%   process
%      Boolean array.

% (C) Copyright 1999-2002               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, March 2002.
