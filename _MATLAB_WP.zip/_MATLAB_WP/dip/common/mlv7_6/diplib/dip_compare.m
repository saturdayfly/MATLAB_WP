%dip_compare   Compares two images.
%    out = dip_compare(in1, in2, op)
%
%   in1
%      Image.
%   in2
%      Image.
%   op
%      String with one of these values: '<', '<=', '~=', '==', '>=', '>'

% (C) Copyright 2011, Cris Luengo.
% Centre for Image Analysis, Uppsala, Sweden.
