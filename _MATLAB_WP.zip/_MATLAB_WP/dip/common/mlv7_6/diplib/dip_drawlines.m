%dip_drawlines (PRIVATE FUNCTION)
%
% use drawpolygon() instead.
