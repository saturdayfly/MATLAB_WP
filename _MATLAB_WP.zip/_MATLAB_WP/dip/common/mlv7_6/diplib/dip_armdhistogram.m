%dip_armdhistogram   Multidimensional histogram.
%   Don't use this function use MDHISTOGRAM instead.
