This is the DIPlib distribution.

Please read the license in 'diplib_license.txt' in the 'licenses' directory.

The DIPteam, 4 March 2010
