function p = cclength(cc,method)

% Compute the perimeter length of an object based on its chainecode :
% (see http://www.cb.uu.se/~cris/blog/index.php/archives/310)
% Based on the DipImage Matlab toolbox
%
% Args: 
%   - cc : chainecode of the object
%   - method : string defining how length is computed
%       * 'count'    : simplest method, just counts border pixels
%       * 'simple'   : Diagonal pixels have a length of sqrt(2)
%       * 'weighted' : Straight and diagonal pixels have weights that
%                      are optimal for a line under a random orientation.
%                      Proffitt and Rosen, 1979.
%       * 'optimal'  : Same as 'weighted', but also counting corners.
%                      Vossepoel and Smeulders, 1982.
%
% Returns :
%   - p : the perimeter length in pixel unit.
%
% Notes:
% Account for the fact we're measuring the length of the chain,
% which joins the pixel centers, and therefore represents a
% slightly smaller object than that we discritized. This
% correction assumes the object is a circle.

switch method

case 'count'
   % The simplest method, just counts border pixels
   p = length(cc);

case 'simple'
   % Diagonal pixels have a length of sqrt(2)
   even = mod(cc,2)==0;
   p = sum(even) + sum(~even)*sqrt(2);

case 'weighted'
   % Straight and diagonal pixels have weights that
   % are optimal for a line under a random orientation.
   % Proffitt and Rosen, 1979.
   even = mod(cc,2)==0;
   p = sum(even)*0.948 + sum(~even)*1.340;

case {'optimal'}
   % Same as 'weighted', but also counting corners.
   % Vossepoel and Smeulders, 1982.
   even = mod(cc,2)==0;
   corner = cc~=[cc(end),cc(1:end-1)];
   p = sum(even)*0.980 + sum(~even)*1.406 - sum(corner)*0.091;
   
end
