% Johnson translator system test

% Here we test the library "Johnson_Curve" to check if the generated random
% series have appropriate moments.

% --> the library Johnson curve does not appear to perform well.
% --> I switched to the built in pearsrnd() function (Pearson system)


%% Setup

addpath('./libraries/Johnson_Curve');

%% kurtosis = 3 varying skewness

    N    = 200*200;           % length of random input sequence
    eta  = normrnd(0,1,N,1);  % random input sequence

    % moments
    m    = 0;   % mean
    sd  = 1;   % rms roughness
    kurt = 3;   % kurtosis (larger than 1)
    
    % compute skewness range from kurtosis :
    % have to fullfil kurt - Skew^2 - 1 > 0
    skew_range = [-sqrt(kurt-1) sqrt(kurt-1)];
    skew_low   = ceil(skew_range(1)*10)/10;
    skew_high  = floor(skew_range(2)*10)/10;
    
    skew = skew_low:0.1:skew_high;  % skewness
    
    valid = kurt - skew.^2 - 1 > 0;  % valid pair of {kurtosis skewness}
       
    % allocate
    n = length(skew);
    new_m    = NaN(n,1);
    new_std  = NaN(n,1);
    new_kurt = NaN(n,1);
    new_skew = NaN(n,1);
    
    for i = 1:length(skew)
        
        moments = {m, sd, skew(i), kurt};

        fprintf('Generating new sequence : ');
        fprintf('m = %1.1d, std = %1.1d, skew = %1.1d, kurt = %1.1d\n', ...
                moments{:});
        
        % johnson system -- bad results
        %{
        param = f_johnson_M(moments{:});
        eta_t = f_johnson_z2y( eta, param.coef, param.type);
        %}
        
        % Pearson system
        [eta_t,type] = pearsrnd(moments{:},N,1);

        
        new_m(i)    = mean(eta_t);
        new_std(i)  = std(eta_t);
        new_kurt(i) = kurtosis(eta_t);
        new_skew(i) = skewness(eta_t);
    end
    
    figure;
    subplot(2,2,1);
    plot(kurt*ones(n,1),new_kurt,'o'); xlabel('Required kurtosis'); ylabel('Generated kurtosis');
    subplot(2,2,2);
    plot(skew,new_skew,'o'); hold on; plot(skew,skew,'-'); hold off;
    xlabel('Required skewness'); ylabel('Generated skewness');
    subplot(2,2,3);
    plot(new_skew,new_kurt,'o');
    xlabel('Generated skewness'); ylabel('Generated kurtosis');
    subplot(2,2,4);
    hist(valid)