function [z, fp, fc] = plotSolution(sigma1,sigma2,L,W,z,angle,curvature)
% Plot graphical resolution of desorption isotherm
%
% Args:
%   - sigma1, sigma2, L, W: functions defining the main equation of
%                           Wenzel Prewetting model (see main script)
%   - z: z coordinates (on which sigma1/2, L and W are indexed)
%   - angle: contact angle in degree
%   - curvature: mean curvature
%
% Returns:
%   - a plot of the graphical resolution

L(1) = 0; L(end) = 0; % fix
sigma_ratio = sigma2./sigma1;
sigma_ratio(1) = 0; sigma_ratio(end) = 0; % fix
theta  = tand(angle);   % angle in radian
Lambda = smooth((sigma_ratio-theta).*L,0.1,'lowess');


figure;
plot(z,Lambda,'-k','linewidth',5); axis off; hold on;
plot(z,2*W*curvature,'--k','linewidth',5); hold off;
figure;
plot(z,Lambda'-2*W*curvature,'-or','erasemode','background');
hold off;

fp = 2*W*curvature;
fc = Lambda;

end

