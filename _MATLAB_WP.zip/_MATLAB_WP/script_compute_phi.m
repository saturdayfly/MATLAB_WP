


phi = 0:1:150;

for k = 1:1:length(phi)

    fprintf('Computing for phi = %d (k = %d)\n',phi(k),k)
    
    [X, Y, Zdata{1}, attributes] = generateEggCartoonHexa(0.03,phi(k),200);

    % parameters
    ROI_size     = 3;            % size of moving window for computeSlope()
    slope_method = 'mldivide';   % method for computeSlope()

    % allocate
    slope_data     = cell(1,num_dataset);
    curvature_data = cell(1,num_dataset);

    % compute slope & curvature
    for i=1:num_dataset
        slope_data{i}           = computeSlope(X,Y,Zdata{i},ROI_size,slope_method);
        [~ , curvature_data{i}] = computeCurvature(X,Y,Zdata{i});
    end

    % concatenate the data
    Z_map     = cell2mat(Zdata);
    slope_map = cell2mat(slope_data);
    curv_map  = cell2mat(curvature_data);
    
       
	mean_amp(k)   = mean(Z_map(:));
    rms_amp(k)    = std(Z_map(:));
    pkpk_amp(k)   = range(Z_map(:));
    skew(k)       = skewness(Z_map(:));
    kurt(k)       = kurtosis(Z_map(:));
    mean_slope(k) = nanmean(slope_map(:));
    rms_slope(k)  = nanstd(slope_map(:));
    mean_curv(k)  = nanmean(curv_map(:));
    rms_curv(k)   = nanstd(curv_map(:));


end