% A few shortcuts to make things simpler
    unit = attributes.unit;
    % Export parameters

    filename = fullfile(dest,'parameters.dat');
    
    header_longname={   'Width of datafile',...
                        'Height of datafile',...
                        'unit',...
                        'lateral pixel size',...
                        'vertical pixel size',...
                        'number of dataset',...
                        'z number of bins',...
                        'slope number of bins',...
                        'curvature number of bins',...
                        'size of fitted plane for slope computation',...
                        'method of slope computation',...
                        'discretization step for theta (linearly spaced)',...
                        'number of curvature values used to compute desorption isotherm (log spaced)',...
                        'maximum mean curvature considered',...
                        'Wenzel angle',...
                        };
        
    header_unit={       'px','px','','',unit,unit,'','','','','px','','deg','',...
                        sprintf('1/%s',unit),sprintf('1/%s',unit),sprintf('1/%s',unit),'rad'}; 
                    
    header_comment={    '','','','','','','','','','','','','','','','','','',''}; 
                    
    parameters = {  num2str(attributes.width),...
                    num2str(attributes.height),...
                    attributes.unit,...
                    num2str(attributes.x_resolution),...
                    num2str(attributes.y_resolution),...
                    num2str(num_dataset),...
                    num2str(length(z)),...
                    num2str(length(dz)),...
                    num2str(length(d2z)),...
                    num2str(ROI_size),...
                    slope_method,...
                    num2str(theta_inc),...
                    num2str(ncurv),...
                    num2str(mcurv_max),...
                    num2str(thetaw)
                    };
                   
    txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
    txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
    txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';
    txt4=sprintf('%s\t',parameters{:}); txt4(end)='';
    dlmwrite(filename,txt1,'delimiter','');
    dlmwrite(filename,txt2,'delimiter','','-append');
    dlmwrite(filename,txt3,'delimiter','','-append');
    dlmwrite(filename,txt4,'delimiter','','-append');
    
    % Export statistical properties

    % statistics 1 : z, p(z), sigma1, sigma 2, average curvature(absolute) + sign and L
        filename = fullfile(dest,'statistic1.dat');

        header_longname ={ 'z',     'z distribution',       'sigma1',   'sigma2',   'Average curvature (absolute value)',   'Average curvature (sign)', 'Length of contour line (per unit area)'  };
        header_unit     ={ unit,    sprintf('1/%s',unit),   '',         '',         sprintf('1/%s',unit),                   '',                         sprintf('1/%s',unit)};
        header_comment  ={ '',      '',                     '',         '',         '',                                     '',                         ''};

        txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
        txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
        txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';

        dlmwrite(filename,txt1,'delimiter','');
        dlmwrite(filename,txt2,'delimiter','','-append');
        dlmwrite(filename,txt3,'delimiter','','-append');

        dlmwrite(filename,[z' p_z' sigma1' sigma2' d2z_z' sign(d2z_z'), L'],'delimiter','\t','-append');

    % statistics 2 : slope distribution
        filename = fullfile(dest,'statistic2.dat');

        header_longname ={'slope',  'slope distribution'    };
        header_unit     ={'',       ''                      };
        header_comment  ={'',       ''                      };

        txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
        txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
        txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';

        dlmwrite(filename,txt1,'delimiter','');
        dlmwrite(filename,txt2,'delimiter','','-append');
        dlmwrite(filename,txt3,'delimiter','','-append');
        dlmwrite(filename,[dz' p_dz'],'delimiter','\t','-append');

    % statistic 3 : curvature distribution absolute + sign
        filename = fullfile(dest,'statistic3.dat');

        header_longname ={'mean curvature (absolute value)',    'total curvature (absolute value)',   'curvature sign',     'curvature distribution'};
        header_unit     ={sprintf('1/%s',unit),                  sprintf('1/%s',unit),                 '',                          unit};
        header_comment  ={'',                                    '',                                  '',                          ''};

        txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
        txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
        txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';

        dlmwrite(filename,txt1,'delimiter','');
        dlmwrite(filename,txt2,'delimiter','','-append');
        dlmwrite(filename,txt3,'delimiter','','-append');
        dlmwrite(filename,[abs(d2z') 2*abs(d2z') sign(d2z') p_d2z'],'delimiter','\t','-append');

    % Export isotherm data to result/isotherm directory
    % We create one file for each value of contact angle
    
    step = 1;  % control the number of outputs
    normfac = nanstd(mcurv_map(:));  % to normalise the mean curvature with the rms mean curvature
    rmsAmp = std(Z_map(:)); % to normalize h
    VP = rmsAmp/sqrt(2*pi); % to normalize the volume
    mkdir(sprintf('%s/isotherms',dest));
    for t = 1:step:length(isotherm)
    
        % filename from theta value
        filename = fullfile(sprintf('%s/isotherms',dest),...
            sprintf('%s%2.1f.dat','theta_',atand(theta_values(t))));
        
        % filename from normalized theta value
        %filename = fullfile(sprintf('%s/isotherms',dest),...
        %    sprintf('%s%2.1f.dat','theta_norm_',theta_norm(t)));
        
        
        
        header_longname ={  'Mean Curvature', 'Total curvature', 'Normalized mean curvature', ...
                            'Film position','Film position (norm)', 'Volume', 'Volume (norm)', 'Stable', ...
                            'h stable',        'h unstable',        'vol stable',        'vol unstable', ...
                            'h stable (norm)', 'h unstable (norm)', 'vol stable (norm)', 'vol unstable (norm)'};
        header_unit     ={sprintf('1/%s',unit), sprintf('1/%s',unit), '', '', '',  '', '', '', '', '','','', '', '', '', ''};
        header_comment  ={'','', '', '', '', '', '', '','','', '', '', '', '', '', ''};

        txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
        txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
        txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';

        dlmwrite(filename,txt1,'delimiter','');
        dlmwrite(filename,txt2,'delimiter','','-append');
        dlmwrite(filename,txt3,'delimiter','','-append');
        dlmwrite(filename,[ isotherm(t).mcurv' ...
                            2*isotherm(t).mcurv' ...
                            isotherm(t).mcurv'/normfac ...
                            isotherm(t).h' ...
                            isotherm(t).h'/rmsAmp ...
                            isotherm(t).vol' ...
                            isotherm(t).vol'/VP ...
                            isotherm(t).stable' ...
                            isotherm(t).h'.*isotherm(t).stable'./isotherm(t).stable' ...
                            isotherm(t).h'.*(1-isotherm(t).stable')./(1-isotherm(t).stable') ...
                            isotherm(t).vol'.*isotherm(t).stable'./isotherm(t).stable' ...
                            isotherm(t).vol'.*(1-isotherm(t).stable')./(1-isotherm(t).stable') ...
                            isotherm(t).h'.*isotherm(t).stable'./isotherm(t).stable'/rmsAmp ...
                            isotherm(t).h'.*(1-isotherm(t).stable')./(1-isotherm(t).stable')/rmsAmp ...
                            isotherm(t).vol'.*isotherm(t).stable'./isotherm(t).stable'/VP ...
                            isotherm(t).vol'.*(1-isotherm(t).stable')./(1-isotherm(t).stable')/VP], ...
                            'delimiter','\t','-append');

    end

    % write phase diagram data to "pd.dat" file                
    
    filename = fullfile(dest,'phase_diagram.dat');
    
    header_longname ={'Mean Curvature', 'Film position', 'volume', 'Angle', 'extrema'};
    header_unit     ={sprintf('1/%s',unit), sprintf('%s',unit), sprintf('%s',unit), 'degree', ''};
    header_comment  ={'', '', '', '', '1 = max, 0 = min'};
    
    txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
    txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
    txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';
    
    dlmwrite(filename,txt1,'delimiter','');
    dlmwrite(filename,txt2,'delimiter','','-append');
    dlmwrite(filename,txt3,'delimiter','','-append');
    dlmwrite(filename,[phase_diagram.mcurv' phase_diagram.h' phase_diagram.vol' phase_diagram.theta' phase_diagram.extrema'],'delimiter','\t','-append');

    % write percolation diagram data to "percolation.dat" file                
    
    filename = fullfile(dest,'percolation.dat');
    
    header_longname ={'Normalized Mean Curvature','Angle'};
    header_unit     ={'', 'degree', ''};
    header_comment  ={'', ''};
    
    txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
    txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
    txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';
    
    dlmwrite(filename,txt1,'delimiter','');
    dlmwrite(filename,txt2,'delimiter','','-append');
    dlmwrite(filename,txt3,'delimiter','','-append');
    dlmwrite(filename,[perc.normcurv' perc.theta'],'delimiter','\t','-append');
    
    % Export statistical properties
    filename = fullfile(dest,'surface_stat.dat');
    
    header_longname={   'mean elevation',...
                        'rms elevation',...
                        'peak-peak elevation',...
                        'skewness',...
                        'kurtosis',...
                        'rms slope',...
                        'rms mean curvature'};
        
    header_unit={       unit,unit,unit,'','','',sprintf('1/%s',unit)}; 
                    
    header_comment={    '','','','','','',''}; 
                    
    parameters = {  num2str(mean(Z_map(:))),...
                    num2str(std(Z_map(:))),...
                    num2str(range(Z_map(:))),...
                    num2str(skewness(Z_map(:))),...
                    num2str(kurtosis(Z_map(:))),...
                    num2str(nanstd(slope_map(:))),...
                    num2str(nanstd(mcurv_map(:)))
                    };
                   
    txt1=sprintf('%s\t',header_longname{:}); txt1(end)='';
    txt2=sprintf('%s\t',header_unit{:}); txt2(end)='';
    txt3=sprintf('%s\t',header_comment{:}); txt3(end)='';
    txt4=sprintf('%s\t',parameters{:}); txt4(end)='';
    dlmwrite(filename,txt1,'delimiter','');
    dlmwrite(filename,txt2,'delimiter','','-append');
    dlmwrite(filename,txt3,'delimiter','','-append');
    dlmwrite(filename,txt4,'delimiter','','-append');
