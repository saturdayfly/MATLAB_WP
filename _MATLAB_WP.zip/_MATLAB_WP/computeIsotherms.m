function isotherm = computeIsotherms(p_z,sigma1,sigma2,L,W,z, ...
                                                 H,theta, ...
                                                 smooth_method,smooth_span, ...
                                                 display)

% Compute desorption isotherms following the method described in :
%
% [1] S. Herminghauss, PRL, 109, 2012
%     "Universal Phase Diagram for Wetting on Mesoscale Roughness"
%
% Args: 
%   - sigma1        : vector of length N, average slope
%   - sigma2        : vector of length N, average square slope
%   - L             : vector of length N, length of contour line
%   - W             : vector of length N, area enclosed by the contour line
%   - z             : vector of length N, surface elevation
%   - dz            : vector of length M, surface slope
%   - pressure      : values of total curvature (== pressure) considered
%   - angle         : values of contact angle considered (in radian)
%   - smooth_method : method for smoothing (default 'lowess')
%   - smooth_span   : span for smoothing (default 0.1)
%   - display       : character string taking the value 'on' or 'off'
%                     enables to display graphical resolution while solving
%
% Returns :
%   - isotherm    : A structure array indexed on theta_vec containing
%                     the following fields : 
%           .mcurv      : the mean curvature
%           .h          : the film position
%           .stable     : 1 if the solution is stable, 0 otherwise
%           .vol        : adsorbed volume
%
% Notes:
%   - In this version (january 2015) we look for all the solutions
%     (both stable and unstable) in order to observe the bifurcations in 
%     the desorption isotherms.
%   - We consider the total curvature (=2*H in the original model) which
%     is analogous to pressure for unit surface tension.

 
% initialize output structure array
% (each structure contains data for a given contact angle)

    isotherm(length(theta)).mcurv  = NaN; % mean curvature
    isotherm(length(theta)).h      = NaN; % film position
    isotherm(length(theta)).stable = NaN; % stable (1) / unstable (0) solution
    isotherm(length(theta)).vol    = NaN; % stable (1) / unstable (0) solution

% Solve for all values of contact angle and pressure
w = waitbar(0,'Initializing waitbar...');

for t = 1:1:length(theta) % loop over contact angle
    
    waitbar(t/length(theta),w,sprintf('Computing phase diagram. %.0f%% along...',t/length(theta)*100))
    
    % Define Lambda function + smooth
    
    L(1) = 0; L(end) = 0; % fix
    sigma_ratio = sigma2./sigma1;
    sigma_ratio(1) = 0; sigma_ratio(end) = 0; % fix
    Lambda  = smooth((sigma_ratio-theta(t)).*L,smooth_span,smooth_method);
    
    for h = 1:1:length(H) % loop over pressure
        
        % Define equation 12 of reference [1] (note we remove a factor 2 because we consider total curvature instead of mean curvature)
        data    = Lambda' - (2*W.*H(h));
        difdata = diff(data);
        
        % find all zeros and check stability
        
        zeros = find(diff(data > 0)); % change '>' to '>=' to systematically
                                      % find the dry state as a valid
                                      % solution
        
        for k = 1:length(zeros)
            
            idx = zeros(k);
            
            % linear interpolation
            line_slope = (data(idx+1)-data(idx))./(z(idx+1)-z(idx));
            
            isotherm(t).mcurv(end+1)   = H(h);
            isotherm(t).h(end+1)      = z(idx)-data(idx)./line_slope;
            
            if difdata(idx) < 0 % stable
                isotherm(t).stable(end+1) = 1;
            else % unstable
                isotherm(t).stable(end+1) = 0;
            end
            
            % Compute volume :
            if idx > 1
                isotherm(t).vol(end+1) = trapz(  z(1:idx),( isotherm(t).h(end)-z(1:idx)).*p_z(1:idx));
            else % only 1 datapoint, cannot integrate, assume volume is zero
                isotherm(t).vol(end+1) = 0;
            end
            
        end
        
        % find zeros at the edges (do not need interpolation here)
        
        zeros_edges = find(data == 0);
        
        for k = 1:length(zeros_edges)
            
            idx = zeros_edges(k);
            
            if idx == 1 %(dry solution)
                %{            
                isotherm(t).mcurv(end+1)   = pressure(h);
                isotherm(t).h(end+1)      = z(1);

                if difdata(idx) < 0 % stable
                    isotherm(t).stable(end+1) = 1;
                else % unstable
                    isotherm(t).stable(end+1) = 0;
                end

                isotherm(t).vol(end+1) = 0;
                %}
            elseif idx == length(data)
                
                isotherm(t).mcurv(end+1)   = H(h);
                isotherm(t).h(end+1)      = z(end);

                if difdata(idx-1) < 0 % stable
                    isotherm(t).stable(end+1) = 1;
                else % unstable
                    isotherm(t).stable(end+1) = 0;
                end

                isotherm(t).vol(end+1) = trapz(  z(1:idx),( isotherm(t).h(end)-z(1:idx)).*p_z(1:idx));          
            end 
        end
        
        
        
        % Plot resolution if display is on
        if strcmp(display,'on') % input argument display = 'on'
            pause(0.5);
            plot(z,Lambda,'ob',z,smooth(Lambda,smooth_span,'loess'),'-b',z,2*W*H(h),'or','erasemode','background');
            if ~isempty(zeros)
                hold on;
                for jj = (length(isotherm(t).h)-length(zeros)+1):length(isotherm(t).h)
                    plot([isotherm(t).h(jj) isotherm(t).h(jj)], [0 max(Lambda)],'-g','LineWidth',2);
                end
                hold off;
            end
            drawnow;
        end
    end

    % sort result by increasing h

    [isotherm(t).h, id] = sort(isotherm(t).h);
    isotherm(t).mcurv   = isotherm(t).mcurv(id);
    isotherm(t).vol     = isotherm(t).vol(id);
    isotherm(t).stable  = isotherm(t).stable(id);


end

close(w);

end