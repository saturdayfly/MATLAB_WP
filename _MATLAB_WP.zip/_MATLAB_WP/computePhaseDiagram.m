function [phase_diagram] = computePhaseDiagram(angle,isotherm)
% Compute phase diagram from desorption isotherms
%
% Args:
%   - angle : a vector of contact angle values considered (in rad)
%   - isotherm    : A structure array containing the desorption isotherm
%                   data, mapped on the angle vector.
%                   (created from computeIsotherms.m).
%                   Contains the fields : 
%           .mcurv      : the mean curvature (== pressure)
%           .h          : the film position
%           .stable     : 1 if the solution is stable, 0 otherwise
%           .vol        : adsorbed volume
%
% returns:
%   - phase_diagram: structure containing the following fields:
%       .mcurv : mean curvature at which bifurcation occurs
%       .h : film position at which bifurcation occurs
%       .extrema : 1 if this corresponds to an maxima (pressure vs film position)
%                  0 is this corresponds to a minima
%       .theta: contact angle at which bifurcation occurs

% initialize output structure array
% (each structure contains data for a given contact angle)

phase_diagram.theta      = NaN; % contact angle
phase_diagram.h          = NaN; % film position
phase_diagram.vol        = NaN; % adsorbed volume
phase_diagram.mcurv      = NaN; % mean curvature
phase_diagram.extrema    = NaN; % 1 if maximum (bifurcation to the left)
                                % 0 if minimum (bifurcation to the right)
                                
for t = 1:length(isotherm)

    theta = atand(angle(t)); % current contact angle in degree
    
    H = isotherm(t).h;      % liquid film position
    P = isotherm(t).mcurv;  % mean curvature vector
    V = isotherm(t).vol;    % adsorbed volume
    
    % sort
    %{
    [~, id] = sort(H);
    H = H(id);
    P = P(id);
    %}

    % solve
    [~,imax,~,imin] = extrema(P);
    
    % delete solution corresponding to edges
    imin(imin==1|imin==length(P)) = [];
    imax(imax==1|imax==length(P)) = [];

    % plot
    %{
    figure
    plot(H,P,'-o')
    hold on
    plot(H(imax),ymax,'r*',H(imin),ymin,'g*')
    %}
    
    if ~isempty(imin)
        for k = imin % store minima
            phase_diagram.theta(end+1)      = theta;
            phase_diagram.h(end+1)          = H(k);
            phase_diagram.vol(end+1)        = V(k);            
            phase_diagram.mcurv(end+1)      = P(k);
            phase_diagram.extrema(end+1)    = 0;        
        end
    end
    
    if ~isempty(imax)
        for k = imax % store maxima
            phase_diagram.theta(end+1)      = theta;
            phase_diagram.h(end+1)          = H(k);
            phase_diagram.vol(end+1)        = V(k);
            phase_diagram.mcurv(end+1)      = P(k);
            phase_diagram.extrema(end+1)    = 1; 
        end
    end
end

end

