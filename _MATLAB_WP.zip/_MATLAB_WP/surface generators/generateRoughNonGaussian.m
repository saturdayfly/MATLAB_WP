function [X, Y, Z, attributes] = generateRoughNonGaussian(num_point,epsilon,scale,varargin)

num_modes = 10; % we work with 10 modes

% q vector and amplitude
[kx, ky] = meshgrid(-num_modes:num_modes); % modes grid
amp = 1;                               % amplitude of first mode
a = amp./sqrt(1+kx.^2+ky.^2);              % amplitudes grid with power law 1/|k|
a(kx==0 & ky==0) = 0;                      % this set the mean elevation to zero

% Phase data (use input phases or generate random phases)
if ~isempty(varargin)
    fh = reshape(varargin{1},2*num_modes+1,2*num_modes+1); %   load phase from .dat file
else
    fh = rand(2*num_modes+1);
end

% Size of periodic box
lx = 1;
ly = 1;

% height function (sum of all modes)
height = @(x,y) sum(sum(a.*sin( 2*pi*(	(kx.*x./lx) + (ky.*y./ly) + fh))));

% Define the grid and compute Z data
[X, Y] = meshgrid(linspace(0,1,num_point));
Z = reshape(cell2mat(arrayfun(height, X(:), Y(:), 'UniformOutput', 0)),num_point,num_point);

% Transform the Gaussian profile into Non-Gaussian
Z = Z + epsilon*Z.^2;
Z = Z*scale;



    attributes.width        = 1;
    attributes.height       = 1;
    attributes.x_resolution = 1/num_point;
    attributes.y_resolution = 1/num_point;
    attributes.unit         = '1';
    
    