%	Script to compute Wetting phase diagram for a randomly rough surface
%	Written by R. DUFOUR - MPIDS/DMI - renaud.dufour@ds.mpg.de
%	Version : April 2015
%
%   This script is based on the following papers :
%
%   [1] S. Herminghauss, PRL, 109, 2012
%       "Universal Phase Diagram for Wetting on Mesoscale Roughness"
%
%   [2] S. Herminghauss, Eur. Phys. J. E., 35(43), 2012
%       "Wetting, Spreading and adsorption on randomly rough surfaces"
%
%               %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   - PART 1    : Load or generate numerically Z profiles
%
%   - PART 2.1  : compute surface slope and curvature
%   - PART 2.2  : compute surface statistical properties
%   - PART 2.3  : compute sigma functions (i.e. dz,dz2 & d2z vs z)
%
%   - PART 3.1   : Compute desorption isotherms
%   - PART 3.2   : Compute phase diagram from desorption isotherms
%
%   - PART 4     : Data export

%% Setup
clearvars -except fh*; close all;
format long;
addpath('surface generators/','libraries/')


%% Part 1 : load or generate surface profile %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load from file
%   [X, Y, Zdata, attributes] = importFromGwyddion();
    
% Generate a surface numerically

    % load phases
    
    [filename, pathname] = uigetfile({'*.*'},'Select files','MultiSelect','on');
    if ischar(filename);
        filelist{1} = filename; % coerce char to cell
    else
        filelist = filename;
    end
    nfh = numel(filelist);

    fhdata       = cell(1,nfh);
    for k=1:nfh
        current_file = fullfile(pathname,filelist{k});
        fhdata{k} = importphases(current_file);
    end

    
% cut = 0.04/3;
% nshift = 0;

epsilon = 0.05;
scale = 0.001;
for kk = 1:nfh
    fprintf('Generating pattern %d/10...\n',kk);
    %[X, Y, Zdata{kk}, attributes] = generateRoughArcotan(10,500,cut,nshift,fh);
    [X, Y, Zdata{kk}, attributes] = generateRoughNonGaussian(500,epsilon,scale,fhdata{kk});
end

%}

%[X, Y, Zdata{1}, attributes] = generateEggCartoonHexa(0.03,90,200);

num_dataset = numel(Zdata);  % number of datasets

% Filtering (optional)
%{
Original_Zdata = Zdata;        % backup
h = fspecial('gaussian',5,3);  % define filter

for k=1:num_dataset
    Zdata{k} = imfilter(Original_Zdata{k},h,'replicate');
end
%}

% Plot
%{
figure('name','Original profile');
surf(X,Y,Original_Zdata{1},'Edgecolor','non');
axis off; view(-38,68); colormap(gray);
%}

figure('name','After Gaussian filtering');
surf(X,Y,Zdata{1},'Edgecolor','k');
%axis unequal;
axis off; view(-30,78);% colormap(gray);


 
%% Part 2.1 : compute slope and curvature %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('Compute Slope and curvature...');

% parameters
ROI_size     = 3;            % size of moving window for computeSlope()
slope_method = 'mldivide';   % method for computeSlope()

% allocate
slope_data      = cell(1,num_dataset);  % Surface slope
mcurvature_data = cell(1,num_dataset);  % Surface Mean curvature

% compute slope & curvature
for k=1:num_dataset
    slope_data{k}            = computeSlope(X,Y,Zdata{k},ROI_size,slope_method);
    [~ , mcurvature_data{k}] = computeCurvature(X,Y,Zdata{k});
end

% concatenate the data
Z_map     = cell2mat(Zdata);
slope_map = cell2mat(slope_data);
mcurv_map  = cell2mat(mcurvature_data);

% make a surface plot with color coding slope
figure('name','After Gaussian filtering');
surf(X,Y,Zdata{1},slope_data{1},'Edgecolor','k');
axis off; view(-38,68);% colormap(gray);
    
fprintf('Done.\n\n');

%% Part 2.2 : compute surface statistics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('Compute Statistical properties...');

fprintf('\n\nMain statistical properties of the pattern : \n')
fprintf('mean(Z) = %f\n',mean(Z_map(:)));
fprintf('rms roughness = %f\n',std(Z_map(:)));
fprintf('peak-to-peak roughness = %f\n',range(Z_map(:)));
fprintf('skewness = %f\n',skewness(Z_map(:)));
fprintf('kurtosis = %f\n',kurtosis(Z_map(:)));
fprintf('rms slope = %f\n',nanstd(slope_map(:)));
fprintf('rms mean curvature = %f\n',nanstd(mcurv_map(:)));

% Select a method to compute statistical quantities
%   - histogram : histogram based approach
%   - kernel    : uses kernel density
stat_method = 'histogram';
% Activate weighting of slope (implemented for histogram method only)
use_weights = 'FALSE';

switch stat_method
    case 'histogram'
        [z, dz, d2z, p_z, p_dz, p_d2z, cp_dz, cp_d2z, z_nbins, dz_nbins, d2z_nbins] = ...
            computeDistributions(Z_map, slope_map, mcurv_map,'weights',use_weights);
    case 'kernel'
        [z, dz, d2z, p_z, p_dz, p_d2z, cp_dz, cp_d2z, global_nbins] = ...
            kdens_stat(Z_map, slope_map, mcurv_map);
end

figure;
subplot(1,3,1); plot(z,p_z,'-bo'); % Height distribution
title('Height distribution (normalized)'); xlabel('h');
subplot(1,3,2); plot(dz,p_dz,'-bo'); % Slope distribution
legend(sprintf('Plane fit (%d*%d pixels)',ROI_size,ROI_size))
title('Slope distribution (normalized)'); xlabel('Slope');
subplot(1,3,3); plot(d2z,p_d2z,'-ro'); % Curvature distribution
legend(sprintf('Plane fit (%d*%d pixels)',ROI_size,ROI_size))
title('Mean Curvature distribution (normalized)'); xlabel('Mean Curvature');

fprintf('Done.\n\n');
    
%% Part 2.3 : compute average slope & curvature as a function of height

fprintf('Compute Sigma functions...');

% Select a method to compute the sigma functions
%    - bining: rely on the slope conditional probability
%    - interpolate: interpolate and average slopes along contour lines
sigma_method = 'bining';

switch sigma_method
    case 'bining'
        dz_z    = NaN(size(z));     % average slope dz function of z
        dz2_z   = NaN(size(z));     % average square slope dz2 function of z
        d2z_z   = NaN(size(z));     % average curvature d2z function of z
        for h=1:1:length(z)
            dz_z(h)     = trapz(dz,cp_dz(:,h)'.*dz);
            dz2_z(h)    = trapz(dz,cp_dz(:,h)'.*dz.^2);
            d2z_z(h)    = trapz(d2z,cp_d2z(:,h)'.*d2z);
        end
    case 'interpolate'
        [dz_z, dz2_z, d2z_z] = InterpolateAlongContour(X,Y,Zdata,slope_data,mcurvature_data, z);
end

figure('name','Average slope, square slope and mean curvature function of elevation','units','normalized','outerposition',[0 0 1 1])
subplot(1,3,1);
plot(z, dz_z,'-ob',z,dz2_z,'-or')
legend('Average slope vs elevation (sigma1)','Average square slope vs elevation (sigma2)');
xlabel('z'); ylabel('sigma1, sigma2');

subplot(1,3,2);
plot(z,dz2_z./dz_z,'-ok')
legend('sigma2/sigma1'); xlabel('z'); ylabel('sigma2/sigma1');

subplot(1,3,3);
plot(z(d2z_z>0),d2z_z(d2z_z>0),'-ob'); hold on;
plot(z(d2z_z<0),abs(d2z_z(d2z_z<0)),'-or'); hold off;
legend('Positive curvature','Negative curvature'); xlabel('z'); ylabel('Mean Curvature');
set(gca,'YScale','log');

fprintf('Done\n\n');

%% Part 2.4 : Compute Euler Characteristics


addpath('dip/common/dipimage');
dip_initialise

EPC        = NaN(size(z));  % Euler characteristic EPC = f(z)
tcl_length = NaN(size(z));
    % film not percolated == high Euler characteristics
    % (lot of separated islands without hole)
    % film percolated == Euler characteristic decreases
    % (islands merge and have 'holes')
    
    % For the egg cartoon the periodicity is not considered
    % otherwise EPC should go from 1 to 0

figure;


    % CODE BELOW DOES NOT TAKE INTO ACCOUNT PIXEL SIZE
    % ASSUMES SQUARE PIXELS
    
for i=1:num_dataset
    for j=1:1:length(z)
        binary = Zdata{i} < z(j);
        %figure(binfig);
        subplot(1,3,1);
        imshow(binary);
        drawnow;
        
        EPC(j) = bweuler(binary);
        subplot(1,3,2);
        %figure(eulerfig);
        plot(z,EPC,'ok');
        drawnow;
        
        image = dip_image(binary);
        [labeled_image, nlab] = dip_label(image,2,'threshold_on_size',2,0,'');

        cc = repmat(struct('label',NaN,'connectivity',NaN,'start',NaN,'chain',NaN,'border','NaN'), nlab, 1 );
        tcl_length(j)=0;
        for k = 1:nlab
            cc(k) = dip_imagechaincode(+labeled_image,2,k); % compute chaincode
            tcl_length(j) = tcl_length(j) + cclength(cc(k).chain,'optimal');
            tcl_length(j) = tcl_length(j) - sum(cc(k).border);
        end
        subplot(1,3,3);
        plot(z,tcl_length,'ok')
        drawnow;
        
        pause(0.1);
    end
    % RESCALE
    tcl_length(:) = tcl_length/size(binary,1)/size(binary,2)/attributes.x_resolution;
end

% TESTS

        image = dip_image(Zdata{1}<0.15);
        [labeled_image, nlab] = dip_label(image,2,'',0,0,'');
        %  labeled_image
        cc = repmat(struct('label',NaN,'connectivity',NaN,'start',NaN,'chain',NaN,'border','NaN'), nlab, 1 );
        for k = 1:nlab
            cc(k) = dip_imagechaincode(+labeled_image,2,k); % compute chaincode
            tcl_length(j) = tcl_length(j) + cclength(cc(k).chain,'optimal');
            
            tcl_length(j) = tcl_length(j) - sum(cc(k).border);
        end


%{
i=2;
directions = [ 1, 0
               1,-1
               0,-1
              -1,-1
              -1, 0
              -1, 1
               0, 1
               1, 1];
border = newim(imsize(image),'bin');
coords = cc(i).start;
for ii=1:length(cc(i).chain)
   border(coords(1),coords(2)) = 1;
   coords = coords + directions(cc(i).chain(ii)+1,:);
end
joinchannels('rgb',image,border')
%}

rmpath('dip/common/dipimage')


%% part 3.1 : Compute desorption isotherms

fprintf('Compute Sigma functions...');

% User input for data processing
prompt = {  'Threshold for phase diagram computation [%]', ...  % Determine the theshold below which the surface is considered as dry ...
            'Theta increment in degree(default 1)',...          %   ... it can be used to compute percolation diagram setting threshold = 0 for example.
            'Curvature : number of values (default 1000)',...
            'Minimal curvature (in power of 10)',...
            'Display graphical resolution (on/off)',...
            'Maximum mean curvature (default : max mean curv of surface)',...
            'method for smoothing',...
            'span for smoothing'};

dlg_title = 'Analasis parameters'; num_lines = 1;
def = {'0','0.5','2000','-5','off',num2str(max(abs(mcurv_map(:)))),'lowess',num2str(0.1)};

answer = inputdlg(prompt,dlg_title,num_lines,def);
threshold        = str2double(answer{1});
theta_inc        = str2double(answer{2});
ncurv            = str2double(answer{3});
p                = str2double(answer{4});
display          = answer{5};
mcurv_max        = str2double(answer{6});
smooth_method    = answer{7};
smooth_span      = str2double(answer{8});

% Define functions sigma1, sigma2, L and W
sigma1 = dz_z;                  % momentum of order 2 of dz
sigma1(1) = 0; sigma1(end) = 0; % fix
sigma2 = dz2_z;                 % momentum of order 2 of dz2
sigma2(1) = 0; sigma2(end) = 0; % fix
L = sigma1.*p_z;                % length of contour line a height z (per surface area
W = NaN(size(z)); W(1) = 0;     % wetted sample area
for h=2:1:length(z)
    W(h) = trapz(z(1:h),p_z(1:h));
end

% Compute Wenzel angle
thetaw = sqrt(trapz(z,sigma2.*p_z));

% Compute desorption isotherms

    % Maximum theta value
    theta_max =  max(smooth(z,sigma2./sigma1,smooth_span,smooth_method));   
    theta_max =  1.5*theta_max;
    
    % theta and curvature vectors (curvature is logspaced)
    logSpacedPressure = logspace(p,log10(mcurv_max),ncurv);
    mcurv_values      = [-fliplr(logSpacedPressure), 0, logSpacedPressure];
    %mcurv_values     = [0, logSpacedPressure];
    
    % Fixed theta (default)
    theta_values      = tand(0:theta_inc:atand(theta_max));
    %theta_values      = tand(0:theta_inc:50);
    
    % theta normalized with the rms slope
    %theta_norm        = [0.1 0.5 1 1.5 2 2.5 3];
    %theta_values      = nanstd(slope_map(:))*theta_norm;
    
    % solve
    isotherm = computeIsotherms( p_z,sigma1,sigma2,L,W,z,...
                                   mcurv_values,theta_values, ...
                                   smooth_method,smooth_span, ...
                                   display);

% Compute the phase diagram
                               
    phase_diagram = computePhaseDiagram(theta_values,isotherm);

% Compute the drying transition
    
    normfac = nanstd(mcurv_map(:)); % normalization factor for curvature
    VP = std(Z_map(:))/sqrt(2*pi);  % percolation volume
    
    drying.normcurv = NaN;
    drying.theta    = NaN;
    for t = 1:length(isotherm)
        id = isotherm(t).vol > 0.01*VP;
        drying.theta(end+1)    = atand(theta_values(t));
        drying.normcurv(end+1) = max(isotherm(t).mcurv(id))/normfac;
    end
    plot(drying.normcurv,drying.theta,'-o');
    set(gca,'XScale','log');
    
% Compute the percolation transition at h == 0
% only look at stable solutions here !
    
    normfac = nanstd(mcurv_map(:)); % normalization factor for curvature
    
    perc.normcurv = NaN;
    perc.theta   = NaN;
    for t = 1:length(isotherm)
        stable = isotherm(t).stable == 1;
        
        id = find(diff(isotherm(t).h(stable)>0)==1);
        if ~isempty(id)
            perc.theta(end+1)    = atand(theta_values(t));
            temp = isotherm(t).mcurv(stable);
            perc.normcurv(end+1) = temp(id+1)/normfac;
        end
    end
    plot(perc.normcurv,perc.theta,'-o');
    set(gca,'XScale','log');

% Plot Results

np = 1; % plot every 'np' value of theta

% Desorption isotherms
    figure('name','Average film position'); hold on;
    colorVec = hsv(2*ceil(length(theta_values)/np)); count = 1;
    for t = 1:np:length(theta_values)
        id = isotherm(t).stable == 1;
        plot(isotherm(t).mcurv(id), isotherm(t).h(id), 'd','Color',colorVec(count,:), ...
            'MarkerFaceColor',colorVec(count,:) );
        plot(isotherm(t).mcurv(~id),isotherm(t).h(~id),'o','Color',colorVec(count,:));
        graphlegend{count} = sprintf('\\theta = %1.1f stable',atand(theta_values(t)));
        graphlegend{count+1} = sprintf('\\theta = %1.1f unstable',atand(theta_values(t)));
        count = count + 2;
    end
    legend(graphlegend); xlabel('Mean Curvature'); ylabel('Average film position');

% Transition Lines
plot(phase_diagram.mcurv(phase_diagram.extrema==1), ...
     phase_diagram.h(phase_diagram.extrema==1), ...
     'o','linewidth',3,'MarkerFaceColor','black','MarkerEdgeColor','black');
 plot(phase_diagram.mcurv(phase_diagram.extrema==0), ...
     phase_diagram.h(phase_diagram.extrema==0), ...
     'o','linewidth',3,'color','black');
%set(gca,'XScale','log');
%set(gca,'YScale','log');

% Volume
    figure('name','Average film position'); hold on;
    colorVec = hsv(2*ceil(length(theta_values)/np)); count = 1;
    for t = 1:np:length(theta_values)
        id = isotherm(t).stable == 1;
        plot(isotherm(t).mcurv(id), isotherm(t).vol(id), 'd','Color',colorVec(count,:), ...
            'MarkerFaceColor',colorVec(count,:) );
        plot(isotherm(t).mcurv(~id),isotherm(t).vol(~id),'o','Color',colorVec(count,:));
        graphlegend{count} = sprintf('\\theta = %1.1f stable',atand(theta_values(t)));
        graphlegend{count+1} = sprintf('\\theta = %1.1f unstable',atand(theta_values(t)));
        count = count + 2;
    end
    legend(graphlegend); xlabel('Mean Curvature'); ylabel('Volume');
    set(gca,'XScale','log');


figure('name','Average film position'); hold on;
plot(phase_diagram.mcurv,phase_diagram.theta,'o');
set(gca,'XScale','log');

% plot in loglog scale
%{
phfig = figure('name','Average film position'); hold on;
colorVec = hsv(ceil(length(angle)/np)); count = 1;
for t = 1:np:length(angle)
    id = isotherm(t).stable == 1;
    
    xx = isotherm(t).curv(id);
    xx(xx>0) = log10(1+xx(xx>0));
    xx(xx<0) = -log10(1-xx(xx<0));
    plot(xx,isotherm(t).h(id),'d','Color',colorVec(count,:), ...
        'MarkerFaceColor',colorVec(count,:) );
    
    xx = isotherm(t).curv(~id);
    xx(xx>0) = log10(1+xx(xx>0));
    xx(xx<0) = -log10(1-xx(xx<0));
    plot(xx,isotherm(t).h(~id),'o','Color',colorVec(count,:));
  
    graphlegend{count} = sprintf('\\theta = %1.1f',atand(angle(t)));
    count = count + 1;
end
legend(graphlegend); xlabel('Curvature H'); ylabel('Average film position');
hold off;
%}

% To plot a graphical resolution for a given angle and curvature use :
% [ex.z, ex.fp, ex.fc] =  plotSolution(sigma1,sigma2,L,W,z,20,0.4) 
% [ex.z, ex.fp, ex.fc] =  plotSolution(sigma1,sigma2,L,W,z,5,1) 

fprintf('Done\n');

%% part 4 : Export data

    prompt = {'Sample name'};
    dlg_title = 'Input sample name for data export';
    def = {'noname'};
    answer = inputdlg(prompt,dlg_title,1,def);

    % initialize output directory
    dest = sprintf('result/%s_%s',datestr(now,29),answer{1});
    if exist(dest,'dir')
        rmdir(dest);
    end
    mkdir(dest)
    
    % Export
    
    fprintf('Exporting data...');

    Script_exportData

    fprintf('Done\n');
    % Export example of Graphical resolution
    
    % TO do
    
% end